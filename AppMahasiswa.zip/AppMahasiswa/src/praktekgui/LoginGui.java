package praktekgui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginGui implements ActionListener {

    private static JTextField userText;
    private static JPasswordField passtext;
    private static JLabel cekLogin;

    public static void main(String[] args) {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        JLabel label = new JLabel("User");
        label.setBounds(10, 20, 80, 25);
        panel.add(label);
        userText = new JTextField();
        userText.setBounds(100, 20, 165, 25);
        panel.add(userText);

        JLabel passlabel = new JLabel("Password");
        passlabel.setBounds(10, 50, 80, 25);
        panel.add(passlabel);

        passtext = new JPasswordField();
        passtext.setBounds(100, 50, 165, 25);
        panel.add(passtext);

        JButton button = new JButton("Login");
        button.setBounds(10, 80, 80, 25);
        button.addActionListener(new LoginGui());
        panel.add(button);

        cekLogin = new JLabel("");
        cekLogin.setBounds(10, 110, 300, 25);
        panel.add(cekLogin);

        frame.setVisible(true);

    }

  
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
public void Connect(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost/mahasiswa","root","");
            } catch (SQLException ex) {
                Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    @Override
    public void actionPerformed(ActionEvent e) {

     try {
            String usernametext = userText.getText();
            String passwordtext = passtext.getText();
            
            pst = con.prepareStatement("select * from datamahasiswa where username=? and password=?");
            pst.setString(1, usernametext);
            pst.setString(2, passwordtext);
            rs = pst.executeQuery();
            
            if (rs.next() == true){
                Mahasiswa open = new Mahasiswa();
                open.setVisible(true);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

}
